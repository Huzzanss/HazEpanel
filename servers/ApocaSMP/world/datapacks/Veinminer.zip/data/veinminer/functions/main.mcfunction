tag @a[scores={mined_co=1..}] add mined_ore
tag @a[scores={mined_di=1..}] add mined_ore
tag @a[scores={mined_go=1..}] add mined_ore
tag @a[scores={mined_ir=1..}] add mined_ore
tag @a[scores={mined_em=1..}] add mined_ore
tag @a[scores={mined_re=1..}] add mined_ore
tag @a[scores={mined_nq=1..}] add mined_ore
tag @a[scores={mined_ng=1..}] add mined_ore
tag @a[scores={mined_la=1..}] add mined_ore
tag @a[scores={mined_cop=1..}] add mined_ore
tag @a[scores={mined_co_d=1..}] add mined_ore
tag @a[scores={mined_di_d=1..}] add mined_ore
tag @a[scores={mined_go_d=1..}] add mined_ore
tag @a[scores={mined_ir_d=1..}] add mined_ore
tag @a[scores={mined_em_d=1..}] add mined_ore
tag @a[scores={mined_re_d=1..}] add mined_ore
tag @a[scores={mined_la_d=1..}] add mined_ore
tag @a[scores={mined_cop_d=1..}] add mined_ore

execute if score flex_pick settings matches 1.. as @a[scores={flex_pick=1..},tag=mined_ore] at @s anchored eyes positioned ^ ^ ^1.5 run execute if entity @s[scores={cooldown=..0}] run function veinminer:veinminer
execute if score dia_pick settings matches 1.. as @a[scores={dia_pick=1..},tag=mined_ore] at @s anchored eyes positioned ^ ^ ^1.5 run execute if entity @s[scores={cooldown=..0}] run function veinminer:veinminer
execute if score iron_pick settings matches 1.. as @a[scores={iron_pick=1..},tag=mined_ore] at @s anchored eyes positioned ^ ^ ^1.5 run execute if entity @s[scores={cooldown=..0}] run function veinminer:veinminer
execute if score gold_pick settings matches 1.. as @a[scores={gold_pick=1..},tag=mined_ore] at @s anchored eyes positioned ^ ^ ^1.5 run execute if entity @s[scores={cooldown=..0}] run function veinminer:veinminer
execute if score stone_pick settings matches 1.. as @a[scores={stone_pick=1..},tag=mined_ore] at @s anchored eyes positioned ^ ^ ^1.5 run execute if entity @s[scores={cooldown=..0}] run function veinminer:veinminer
execute if score wood_pick settings matches 1.. as @a[scores={wood_pick=1..},tag=mined_ore] at @s anchored eyes positioned ^ ^ ^1.5 run execute if entity @s[scores={cooldown=..0}] run function veinminer:veinminer
tag @a[tag=mined_ore] remove mined_ore

scoreboard players set @a mined_co 0
scoreboard players set @a mined_di 0
scoreboard players set @a mined_go 0
scoreboard players set @a mined_ir 0
scoreboard players set @a mined_em 0
scoreboard players set @a mined_re 0
scoreboard players set @a mined_nq 0
scoreboard players set @a mined_ng 0
scoreboard players set @a mined_la 0
scoreboard players set @a mined_cop 0
scoreboard players set @a mined_co_d 0
scoreboard players set @a mined_di_d 0
scoreboard players set @a mined_go_d 0
scoreboard players set @a mined_ir_d 0
scoreboard players set @a mined_em_d 0
scoreboard players set @a mined_re_d 0
scoreboard players set @a mined_la_d 0
scoreboard players set @a mined_cop_d 0


# Cooldown Handling
execute as @a run execute unless score @s cooldown matches 0.. run scoreboard players set @s cooldown 0
execute as @a[scores={cooldown=1..}] run scoreboard players remove @s cooldown 1
